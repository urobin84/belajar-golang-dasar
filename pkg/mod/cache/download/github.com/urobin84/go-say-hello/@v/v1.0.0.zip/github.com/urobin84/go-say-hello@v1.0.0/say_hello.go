package go_say_hello

func SayHello() string {
	return "Hello"
}
